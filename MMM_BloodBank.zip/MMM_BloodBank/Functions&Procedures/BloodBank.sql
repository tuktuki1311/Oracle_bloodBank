DROP TABLE DONOR CASCADE CONSTRAINTS;
DROP TABLE EMPLOYEE1 CASCADE CONSTRAINTS;
DROP TABLE AVAILABILITY CASCADE CONSTRAINTS;
DROP TABLE REQUESTER CASCADE CONSTRAINTS;
DROP TABLE INVENTORY1 CASCADE CONSTRAINTS;
DROP TABLE BLOOD CASCADE CONSTRAINTS;

CREATE TABLE BLOOD(
	bloodId int, 
	bloodType varchar2(30), 	
        PRIMARY KEY(bloodId)); 

CREATE TABLE INVENTORY1(
	inventoryId int, 
	city varchar2(30), 
	inventoryCon varchar2(30),
	inventoryAdd varchar2(30),
        PRIMARY KEY(inventoryId)); 

CREATE TABLE AVAILABILITY(
	avId int, 
	bloodId int,
	inventoryId int,	
        PRIMARY KEY(avId));

CREATE TABLE Donor (
	donorId int, 
	donorName varchar2(30), 
	donorContact varchar2(30), 
	donorAge int,
	bloodid int,
	smoker varchar2(10), 
	addiction varchar2(20), 
	gender char(10), 
	height number(5,2),
	weight number(5,2),
        PRIMARY KEY(donorId)); 

CREATE TABLE EMPLOYEE1(
	EmpId int, 
	EmpName varchar2(30), 
	EmpContact varchar2(30),
	Salary int,
	Rank varchar2(20),
	inventoryId int,
	PRIMARY KEY(EmpId));

 
CREATE TABLE REQUESTER(
	reqId int, 
	reqName varchar2(30), 
	reqContact varchar2(30), 
	reqBloodid int, 
	amount int,
        PRIMARY KEY(reqId)); 




insert into BLOOD (bloodId, bloodType) values (1, 'A+');
insert into BLOOD (bloodId, bloodType) values (2, 'A-');
insert into BLOOD (bloodId, bloodType) values (3, 'AB+');
insert into BLOOD (bloodId, bloodType) values (4, 'AB-');
insert into BLOOD (bloodId, bloodType) values (5, 'B+');
insert into BLOOD (bloodId, bloodType) values (6, 'B-');
insert into BLOOD (bloodId, bloodType) values (7, 'O+');
insert into BLOOD (bloodId, bloodType) values (8, 'O-');

--insert into INVENTORY (inventoryId, city, inventoryCon, inventoryAdd) values (1, 'Dhaka','019','23/1 Baily Road');
--insert into INVENTORY (inventoryId, city, inventoryCon, inventoryAdd) values (2, 'Ctg', '016' ,'32-GEC CIRCLE;);
--insert into INVENTORY (inventoryId, city, inventoryCon, inventoryAdd) values (3, 'Rangpur');

insert into AVAILABILITY (avId, bloodId, inventoryId) values (1, 1, 1);
insert into AVAILABILITY (avId, bloodId, inventoryId) values (2, 1, 2);
insert into AVAILABILITY (avId, bloodId, inventoryId) values (3, 1, 5);
insert into AVAILABILITY (avId, bloodId, inventoryId) values (4, 2, 1);
insert into AVAILABILITY (avId, bloodId, inventoryId) values (5, 2, 3);

insert into Donor (donorId, donorName, donorContact, donorAge, bloodid,smoker, addiction, gender, height,weight) values (1, 'Pablo Escobar', '93456', 21, 1, 'No', 'NONE', 'MALE', 5.7, 75);
insert into Donor (donorId, donorName, donorContact, donorAge, bloodid,smoker, addiction, gender, height,weight) values (2, 'El Chapo', '93356', 19, 1, 'No', 'NONE', 'MALE', 4.9, 67);
insert into Donor (donorId, donorName, donorContact, donorAge, bloodid,smoker, addiction, gender, height,weight) values (3, 'Javier Penna', '92456', 30, 2, 'YES', 'NONE', 'MALE', 5.1, 70);
insert into Donor (donorId, donorName, donorContact, donorAge, bloodid,smoker, addiction, gender, height,weight) values (4, 'Morphe White', '931156', 18, 6, 'No', 'NONE', 'MALE', 6.1, 85);
insert into Donor (donorId, donorName, donorContact, donorAge, bloodid,smoker, addiction, gender, height,weight) values (5, 'Walter White', '92136', 29, 7, 'YES', 'NONE', 'MALE', 5.11, 77);


--insert into EMPLOYEE (EmpId, EmpName, EmpContact, Salary, Rank, inventoryId) values (1, 'Sheldon', '9234', 5000, 'Receptionist',1);
--insert into EMPLOYEE (EmpId, EmpName, EmpContact, Salary, Rank, inventoryId) values (2, 'Howard', '9234', 70000, 'Doctor',1);
--insert into EMPLOYEE (EmpId, EmpName, EmpContact, Salary, Rank, inventoryId) values (3, 'Rajesh', '9234', 15000, 'Nurse',1);
--insert into EMPLOYEE (EmpId, EmpName, EmpContact, Salary, Rank, inventoryId) values (4, 'Lenoard', '9234', 5000, 'Receptionist',2);
--insert into EMPLOYEE (EmpId, EmpName, EmpContact, Salary, Rank, inventoryId) values (5, 'Penny', '9234', 70000, 'Doctor',2);
--insert into EMPLOYEE (EmpId, EmpName, EmpContact, Salary, Rank, inventoryId) values (6, 'Bernedatter', '9234', 15000, 'Nurse',2);
--insert into EMPLOYEE (EmpId, EmpName, EmpContact, Salary, Rank, inventoryId) values (7, 'Amy', '9234', 955000, 'Admin',1);

insert into REQUESTER (reqId, reqName, reqContact, reqBloodid, amount) values (1, 'Mike ', '73456', 1, 3);
insert into REQUESTER (reqId, reqName, reqContact, reqBloodid, amount) values (2, 'Hannah', '81456', 6, 1);
insert into REQUESTER (reqId, reqName, reqContact, reqBloodid, amount) values (3, 'Justin ', '67456', 2, 1);
insert into REQUESTER (reqId, reqName, reqContact, reqBloodid, amount) values (4, 'Jessica ', '93456', 5, 5);
insert into REQUESTER (reqId, reqName, reqContact, reqBloodid, amount) values (5, 'Alex', '73236', 4, 2);

--SELECT * FROM REQUESTER;
--SELECT * FROM BLOOD;
SELECT * FROM INVENTORY1;
--SELECT * FROM DONOR;
--SELECT * FROM AVAILABILITY;
SELECT * FROM EMPLOYEE1;
 

commit;
 