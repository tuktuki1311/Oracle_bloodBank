create or replace procedure nurseInfo
	(a_city in INVENTORY.city%TYPE, e_rank in EMPLOYEE.Rank%TYPE,e_name out EMPLOYEE.EmpName%TYPE,e_con out EMPLOYEE.EmpContact%Type,e_sal out EMPLOYEE.Salary%Type)
	is
	
	cursor nurseInfo_cur is
	SELECT EMPLOYEE.EmpName, EMPLOYEE.EmpContact, EMPLOYEE.Salary FROM EMPLOYEE INNER JOIN INVENTORY ON 
	EMPLOYEE.inventoryId = INVENTORY.inventoryId where EMPLOYEE.Rank = e_rank
	AND INVENTORY.city = a_city;
	
	
BEGIN
	open nurseInfo_cur;
	loop
	fetch nurseInfo_cur into e_name,e_con,e_sal;
	exit when nurseInfo_cur%notfound;
	dbms_output.put_line( 'Not Simplified----');
	dbms_output.put_line( 'Nurse Name:    ' || e_name);
	dbms_output.put_line( 'Nurse Contact:    ' || e_con);
	dbms_output.put_line( 'Nurse Salary:    ' || e_sal);
	end loop;
	close nurseInfo_cur;
end;
/
create or replace procedure nurseInfoSimplified
	(a_city in INVENTORY.city%TYPE, e_rank in EMPLOYEE.Rank%TYPE,e_name out EMPLOYEE.EmpName%TYPE,e_con out EMPLOYEE.EmpContact%Type,e_sal out EMPLOYEE.Salary%Type)
	is
	
	cursor nurseInfo_cur is
	SELECT EMPLOYEE.EmpName, EMPLOYEE.EmpContact, EMPLOYEE.Salary FROM EMPLOYEE where EMPLOYEE.Rank = e_rank AND EMPLOYEE.inventoryId= 
	(SELECT inventoryId FROM INVENTORY where INVENTORY.city = a_city);
	
	
BEGIN
	open nurseInfo_cur;
	loop
	fetch nurseInfo_cur into e_name,e_con,e_sal;
	exit when nurseInfo_cur%notfound;
	  
	dbms_output.put_line( 'Simplified----');
	dbms_output.put_line( 'Nurse Name:    ' || e_name);
	dbms_output.put_line( 'Nurse Contact:    ' || e_con);
	dbms_output.put_line( 'Nurse Salary:    ' || e_sal);
	end loop;
	close nurseInfo_cur;
end;
/