create or replace procedure BloodInfo
	(btype in BLOOD.bloodType%TYPE,a_city out INVENTORY.city%TYPE)
	is
	
	cursor BloodInfo_cur is
	SELECT INVENTORY.city FROM INVENTORY where INVENTORY.inventoryId in (
   (SELECT AVAILABILITY.inventoryId FROM AVAILABILITY where AVAILABILITY.bloodId = 
   (SELECT BLOOD.bloodId FROM BLOOD where BLOOD.bloodType = btype)));
	
	
BEGIN
	open BloodInfo_cur;
	loop
	fetch BloodInfo_cur into a_city;
	exit when BloodInfo_cur%notfound;
	 
	dbms_output.put_line( 'Available City:    ' || a_city);
	end loop;
	close BloodInfo_cur;
end;
/

