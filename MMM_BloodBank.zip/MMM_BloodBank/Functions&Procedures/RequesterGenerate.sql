SET SERVEROUTPUT ON;

DECLARE 
	b_id BLOOD.bloodId%TYPE;
	b_type BLOOD.bloodType%TYPE;
	
	r_id REQUESTER.reqId%TYPE; 
BEGIN

	b_type := 'O+';
	b_id := findBloodId(b_type);
	
	select Rid.nextval into r_id from dual;
	
	--dbms_output.put_line('blood type ' || b_id);
	insert into REQUESTER (reqId,reqName,reqContact,reqBloodid,amount) values (r_id,'Dolores','019',b_id,3);
END;
/