SET SERVEROUTPUT ON;

CREATE OR REPLACE TRIGGER display_donor_changes 
BEFORE DELETE OR INSERT OR UPDATE ON DONOR 
FOR EACH ROW 
WHEN (NEW.donorId > 0) 
DECLARE 
   
BEGIN 
  
   dbms_output.put_line('Old Id: ' || :OLD.donorId);
   dbms_output.put_line('Old Smoker Status: ' || :OLD.Smoker);
   dbms_output.put_line('New Smoker Status: ' || :NEW.Smoker); 
   
END; 
/ 