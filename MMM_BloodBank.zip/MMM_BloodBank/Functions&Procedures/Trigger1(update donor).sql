UPDATE Donor 
SET smoker = 'No'
WHERE smoker = 'YES'; 
