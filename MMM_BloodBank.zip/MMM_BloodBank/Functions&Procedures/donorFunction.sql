create or replace function findSmokerDonor(smoke Donor.smoker%TYPE)
	return number 
	is
	cnt1 number;
BEGIN
	select count(*) into cnt1 from Donor where smoker = smoke;
	return cnt1;
end findSmokerDonor;
/