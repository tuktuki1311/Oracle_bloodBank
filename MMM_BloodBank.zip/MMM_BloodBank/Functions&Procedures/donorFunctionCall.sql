SET SERVEROUTPUT ON;

DECLARE 
	cnt number;
	smoke Donor.smoker%TYPE;
BEGIN
	smoke := 'YES';
	cnt := findSmokerDonor(smoke);
	dbms_output.put_line('smoker number' || cnt);
END;
/