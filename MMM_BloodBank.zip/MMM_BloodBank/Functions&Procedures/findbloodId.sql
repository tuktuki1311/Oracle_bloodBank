create or replace function findBloodId(btype BLOOD.bloodType%TYPE)
	return BLOOD.bloodId%TYPE
	is
	bid BLOOD.bloodId%TYPE;
BEGIN
	select BLOOD.bloodId into bid from BLOOD where BLOOD.bloodType = btype;
	return bid;
end findBloodId;
/