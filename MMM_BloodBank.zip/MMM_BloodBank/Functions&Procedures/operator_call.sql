SET SERVEROUTPUT ON;

DECLARE 

	a_city INVENTORY.city%TYPE;
	
	e_con EMPLOYEE.EmpContact%Type;  
	e_sal EMPLOYEE.Salary%Type;
	e_rank EMPLOYEE.Rank%TYPE;
	e_name EMPLOYEE.EmpName%TYPE;
	
BEGIN
 
	
	a_city := 'Dhaka';
	e_rank := 'Nurse';

	nurseInfo(a_city,e_rank,e_name,e_con,e_sal);
	nurseInfoSimplified(a_city,e_rank,e_name,e_con,e_sal);

	
	
END;
/