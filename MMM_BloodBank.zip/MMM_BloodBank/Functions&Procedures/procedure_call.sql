SET SERVEROUTPUT ON;

DECLARE 
	b_type BLOOD.bloodType%TYPE;
	a_city INVENTORY.city%TYPE;
	
	
BEGIN
 
	b_type := 'A-';
	a_city := 'Dhaka';
	
	 BloodInfo(b_type,a_city);
	
	
	
END;
/