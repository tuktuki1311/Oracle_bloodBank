SET SERVEROUTPUT ON;

CREATE OR REPLACE TRIGGER display_employee1_changes 
BEFORE DELETE OR INSERT OR UPDATE ON EMPLOYEE2
FOR EACH ROW 
WHEN (NEW.EmpId > 0) 
DECLARE 
   sal_diff number; 
BEGIN 
   
   dbms_output.put_line('New Id: ' || :NEW.EmpId); 
  
END; 
/ 