
DECLARE 
	e_id EMPLOYEE.EmpId%Type;
	e_name EMPLOYEE.EmpName %Type;
	e_con EMPLOYEE.EmpContact%Type;  
	e_sal EMPLOYEE.Salary%Type;
	e_desig EMPLOYEE.Rank%Type; 
	e_outid EMPLOYEE.inventoryId%Type;   
	

	cursor out_emp is
	Select EmpId,EmpName,EmpContact,Salary,Rank,inventoryId
	from EMPLOYEE1;	
	
BEGIN 
	
	Select EmpId Into e_id from EMPLOYEE1 where Rank = 'Admin' AND inventoryId = (SELECT inventoryId FROM Inventory Where city = 'Dhaka');
	
	
	DELETE FROM EMPLOYEE1 where EmpId = e_id;
	
	 open out_emp;
  
  loop
		fetch out_emp 
		into e_id,e_name,e_con,e_sal,e_desig,e_outid;
		exit when out_emp%notFound;
		

		dbms_output.put_line(e_id || ' ' || e_name  || ' ' || e_con || ' ' || e_sal || ' ' || e_desig || ' ' || e_outid);
		end loop;
	close out_emp;  

EXCEPTION 
  
   WHEN no_data_found THEN 
      dbms_output.put_line('No such Data!'); 
 
END; 
/