set serveroutput on;
    
declare	
	i_id INVENTORY.inventoryId%Type;
	i_city INVENTORY.city%Type;
	i_con INVENTORY.inventoryCon%Type;  
	i_add INVENTORY.inventoryAdd%Type;
	
	
	cursor out_inv is
	Select inventoryId,city,inventoryCon,inventoryAdd
	from INVENTORY where city = 'Dhaka';
	
	
	
BEGIN
  open out_inv;
  
  loop
		fetch out_inv
		into i_id,i_city,i_con,i_add;
		exit when out_inv%notFound;
		
		insert into INVENTORY1 values(i_id,i_city,i_con,i_add);
		dbms_output.put_line(i_id || ' ' || i_city  || ' ' || i_con || ' ' || i_add);
		--insert into INVENTORY1@site_link values(i_id,i_city,i_con,i_add);
		
  end loop;
  close out_inv;  
	
   EXCEPTION 
   WHEN no_data_found THEN 
      dbms_output.put_line('No Data Found!'); 

	end;
	/
