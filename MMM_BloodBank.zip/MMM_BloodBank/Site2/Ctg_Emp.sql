set serveroutput on;

declare	
	e_id EMPLOYEE.EmpId%Type;
	e_name EMPLOYEE.EmpName %Type;
	e_con EMPLOYEE.EmpContact%Type;  
	e_sal EMPLOYEE.Salary%Type;
	e_desig EMPLOYEE.Rank%Type; 
	e_outid EMPLOYEE.inventoryId%Type;   
	
	cursor out_emp is
	Select EmpId,EmpName,EmpContact,Salary,Rank,inventoryId
	from EMPLOYEE where inventoryId in (Select inventoryId from INVENTORY where city = 'Ctg');

BEGIN
  open out_emp;
  
  
  loop
		fetch out_emp
		
		into e_id,e_name,e_con,e_sal,e_desig,e_outid;
		exit when out_emp%notFound;
		
		
		--insert into INVENTORY1@site_link values(i_id,i_city,i_con,i_add);
		insert into EMPLOYEE2@site_link values(e_id,e_name,e_con,e_sal,e_desig,e_outid);
		dbms_output.put_line(e_id || ' ' || e_name  || ' ' || e_con || ' ' || e_desig);
		
  end loop;
  close out_emp;  
	
   EXCEPTION 
   WHEN no_data_found THEN 
      dbms_output.put_line('No Data Found!'); 

	end;
	/
commit;