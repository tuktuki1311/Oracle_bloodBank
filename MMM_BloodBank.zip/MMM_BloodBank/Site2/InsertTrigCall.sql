DECLARE 
	e_id EMPLOYEE.EmpId%Type;
	e_name EMPLOYEE.EmpName %Type;
	e_con EMPLOYEE.EmpContact%Type;  
	e_sal EMPLOYEE.Salary%Type;
	e_desig EMPLOYEE.Rank%Type; 
	e_outid EMPLOYEE.inventoryId%Type;   
	
	
	
BEGIN 
	
	Select EmpId,EmpName,EmpContact,Salary,Rank,inventoryId
	Into e_id,e_name,e_con,e_sal,e_desig,e_outid
	from EMPLOYEE1 where Rank = 'Admin' AND inventoryId = (SELECT inventoryId FROM Inventory Where city = 'Dhaka');
	
      DBMS_OUTPUT.PUT_LINE ('Name: '||  e_name);  
      DBMS_OUTPUT.PUT_LINE ('Inventory Id: ' || e_outid);
	
	insert into EMPLOYEE2@site_link values(e_id,e_name,e_con,e_sal,e_desig,2);
	
	
	--DELETE FROM EMPLOYEE2 where EmpId = e_id;

EXCEPTION 
  
   WHEN no_data_found THEN 
      dbms_output.put_line('No such Data!'); 
 
END; 
/