SET SERVEROUTPUT ON;

CREATE OR REPLACE TRIGGER display_employee_changes 
BEFORE DELETE OR INSERT OR UPDATE ON EMPLOYEE2@site_link
FOR EACH ROW 
WHEN (NEW.EmpId > 0) 
DECLARE 
   --sal_diff number; 
BEGIN 
    
   dbms_output.put_line('New Id: ' || :NEW.EmpId);
   dbms_output.put_line('New Id: ' || :NEW.EmpName);
   dbms_output.put_line('New Id: ' || :NEW.Rank); 
 
END; 
/ 