drop database link site_link;

create database link site_link
connect to system identified by "123"
using '(DESCRIPTION = 

(ADDRESS_LIST = 
(ADDRESS = (PROTOCOL = TCP)
(HOST = 172.20.10.5)
(PORT = 1521))

(CONNECT_DATA = (SID = XE))
)'
;